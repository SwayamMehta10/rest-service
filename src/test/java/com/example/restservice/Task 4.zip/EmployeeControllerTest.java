package com.example.restservice;

import org.springframework.http.MediaType;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.hamcrest.Matchers.*;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {
    @Autowired
    MockMvc mockMvc;
    
    @Autowired
    ObjectMapper objectMapper;

    @MockBean
    EmployeeManager employeeManager;

    @InjectMocks
    EmployeeController employeeController;

    Employee emp1 = new Employee(1, "Swayam", "Mehta", "swam10@gmail.com", "Co-Founder");
    Employee emp2 = new Employee(2, "Shubhangi", "Tiwari", "rimjhim11@gmail.com", "Co-Founder");
    Employee emp3 = new Employee(3, "Nikhil", "Agarwal", "niks20@gmail.com", "Co-Founder");

    @Test
    public void getEmployeeList_success() throws Exception {
        Employees employeeList = new Employees();
        employeeList.getEmployeeList().add(emp1);
        employeeList.getEmployeeList().add(emp2);
        employeeList.getEmployeeList().add(emp3);

        Mockito.when(employeeManager.getAllEmployees()).thenReturn(employeeList);
    
        mockMvc.perform(MockMvcRequestBuilders
            .get("/employees/")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.employeeList", hasSize(3)))
            .andExpect(jsonPath("$.employeeList[0].firstName", is("Swayam")));
    }

}
